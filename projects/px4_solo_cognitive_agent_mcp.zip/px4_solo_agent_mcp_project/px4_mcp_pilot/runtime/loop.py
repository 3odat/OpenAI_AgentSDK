
import asyncio
from agents import Runner
from .sessions import get_session
from ..context import UAVContext
from ..agent import create_agent
from ..safety.guardrails import BatteryGuard, GeofenceGuard

async def mission_loop(ctrl, mcp_url: str = "http://localhost:5090/mcp") -> None:
    agent = create_agent(mcp_url=mcp_url)
    ctx = UAVContext(ctrl=ctrl)
    session = get_session()

    # Seed
    try:
        await Runner.run(agent, "bootstrap", context=ctx, session=session)
    except Exception:
        pass

    # Continuous (you can switch to event-driven triggers in app.server)
    while True:
        result = Runner.run_streamed(
            agent,
            "Maintain patrol and respond to new targets and safety events.",
            context=ctx,
            session=session,
            run_config={
                "input_guardrails": [BatteryGuard()],
                "output_guardrails": [GeofenceGuard()],
            },
        )
        async for event in result.stream_events():
            _ = event
        await asyncio.sleep(1.0)
