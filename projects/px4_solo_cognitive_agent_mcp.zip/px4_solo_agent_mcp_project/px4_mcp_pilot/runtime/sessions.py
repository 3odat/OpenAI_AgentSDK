
from agents import SQLiteSession, Session

def get_session(drone_id: str = "drone1") -> Session:
    return SQLiteSession(f"uav_{drone_id}", "./sessions.db")
