
from dataclasses import dataclass, field
from typing import Any, Dict

# Import the user's controller
try:
    from Agentic_Controller_v4 import AgenticController
except Exception as e:
    raise ImportError(
        "Couldn't import AgenticController from Agentic_Controller_v4.py. "
        "Place the file at project root or add it to PYTHONPATH."
    ) from e

@dataclass
class UAVContext:
    ctrl: AgenticController
    caches: Dict[str, Any] = field(default_factory=dict)
    params: Dict[str, Any] = field(default_factory=lambda: {
        "home": None,  # (lat, lon, abs_alt)
        "geofence": {"center": None, "radius_m": 800.0},
        "min_batt": 0.25,          # Block flight actions below 25%
        "loiter_alt_m": 20.0,
        "cruise_speed_mps": 4.0,
    })
