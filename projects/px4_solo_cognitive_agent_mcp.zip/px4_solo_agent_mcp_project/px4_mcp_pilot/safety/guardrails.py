
from typing import Any, Dict, Tuple
from agents import InputGuardrail, OutputGuardrail, GuardrailFunctionOutput, RunContextWrapper

def _inside_geofence(center: Tuple[float, float] | None, radius_m: float, lat: float, lon: float) -> bool:
    if not center:
        return True
    import math
    lat1, lon1 = center
    R = 6371000.0
    x = math.radians(lon - lon1) * math.cos(math.radians((lat + lat1) / 2))
    y = math.radians(lat - lat1)
    d = (R * (x*x + y*y) ** 0.5)
    return d <= radius_m

class BatteryGuard(InputGuardrail):
    name = "battery_guard"
    instructions = "Block hazardous flight actions when battery below min_batt."

    async def call(self, user_input: str, context: RunContextWrapper[Any]) -> GuardrailFunctionOutput:
        sensors: Dict[str, Any] = context.context.caches.get("last_sensors", {}) if context else {}
        batt = sensors.get("battery", None)
        if batt is not None and batt < context.context.params.get("min_batt", 0.25):
            return GuardrailFunctionOutput(blocked=True, reason=f"Battery too low: {batt:.2f}")
        return GuardrailFunctionOutput(blocked=False)

class GeofenceGuard(OutputGuardrail):
    name = "geofence_guard"
    instructions = "Prevent navigation outside geofence; replace with RTL."

    async def call(self, model_output: str, context: RunContextWrapper[Any]) -> GuardrailFunctionOutput:
        import json
        try:
            payload = json.loads(model_output)
        except Exception:
            payload = None
        if not isinstance(payload, dict):
            return GuardrailFunctionOutput(blocked=False)
        steps = payload.get("steps", [])
        center = context.context.params.get("geofence", {}).get("center")
        radius = context.context.params.get("geofence", {}).get("radius_m", 800.0)
        violated = False
        for s in steps:
            if s.get("action") == "goto":
                lat = float(s["args"].get("lat"))
                lon = float(s["args"].get("lon"))
                if not _inside_geofence(center, radius, lat, lon):
                    violated = True
                    break
        if violated:
            return GuardrailFunctionOutput(blocked=True, replacement="{'intent':'safety_rtl','steps':[{'action':'rtl','args':{}}]}")
        return GuardrailFunctionOutput(blocked=False)
