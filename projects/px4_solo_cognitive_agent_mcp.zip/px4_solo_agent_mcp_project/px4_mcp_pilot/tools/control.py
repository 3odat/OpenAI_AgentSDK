
from typing import Optional
from agents import function_tool, RunContextWrapper

@function_tool
async def connect(ctx: RunContextWrapper["UAVContext"]) -> str:
    await ctx.context.ctrl._ensure_connected()  # pylint: disable=protected-access
    # Populate home/geofence center once
    try:
        pos = await ctx.context.ctrl._await_first(ctx.context.ctrl.drone.telemetry.position())  # type: ignore[attr-defined]  # pylint: disable=protected-access
        ctx.context.params["home"] = (pos.latitude_deg, pos.longitude_deg, pos.absolute_altitude_m)
        if ctx.context.params["geofence"]["center"] is None:
            ctx.context.params["geofence"]["center"] = (pos.latitude_deg, pos.longitude_deg)
    except Exception:
        pass
    return "connected"

@function_tool
async def arm(ctx: RunContextWrapper["UAVContext"]) -> str:
    await ctx.context.ctrl._ensure_connected()  # pylint: disable=protected-access
    await ctx.context.ctrl._ensure_armed()      # pylint: disable=protected-access
    return "armed"

@function_tool
async def takeoff(ctx: RunContextWrapper["UAVContext"], alt_m: float = 3.0) -> str:
    await ctx.context.ctrl.takeoff(alt_m)
    return f"takeoff_to_{alt_m}m"

@function_tool
async def goto(ctx: RunContextWrapper["UAVContext"], lat: float, lon: float, alt_abs_m: Optional[float] = None) -> str:
    await ctx.context.ctrl.goto(lat, lon, alt_abs_m)
    return "goto_ok"

@function_tool
async def loiter(ctx: RunContextWrapper["UAVContext"], seconds: int = 10) -> str:
    await ctx.context.ctrl.stop()
    return f"loiter_{seconds}s"

@function_tool
async def land(ctx: RunContextWrapper["UAVContext"]) -> str:
    await ctx.context.ctrl.land()
    return "landing"

@function_tool
async def rtl(ctx: RunContextWrapper["UAVContext"]) -> str:
    await ctx.context.ctrl.rtl()
    return "rtl"

@function_tool
async def orbit(ctx: RunContextWrapper["UAVContext"], radius_m: float, direction: str = "cw", speed_mps: float = 1.5, return_to_center: bool = False) -> str:
    await ctx.context.ctrl.orbit(radius_m, direction, speed_mps, return_to_center)
    return "orbit_complete"

@function_tool
async def look_down(ctx: RunContextWrapper["UAVContext"], degrees: float = 90.0) -> str:
    await ctx.context.ctrl.look_down(degrees)
    return "look_down_ok"

@function_tool
async def look_forward(ctx: RunContextWrapper["UAVContext"]) -> str:
    await ctx.context.ctrl.look_forward()
    return "look_forward_ok"

@function_tool
async def stop(ctx: RunContextWrapper["UAVContext"]) -> str:
    await ctx.context.ctrl.stop()
    return "stop_ok"
