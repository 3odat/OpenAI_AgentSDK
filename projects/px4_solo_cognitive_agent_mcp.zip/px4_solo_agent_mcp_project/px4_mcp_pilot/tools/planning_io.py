
from pydantic import BaseModel, Field
from typing import List, Literal, Optional, Tuple, Dict, Any

class SceneObject(BaseModel):
    object_name: str
    confidence: float
    xyz: Tuple[float, float, float] | None = None
    gps: Tuple[float, float] | None = None

class Scene(BaseModel):
    detections: List[SceneObject] = Field(default_factory=list)
    timestamp: float | None = None

class Sensors(BaseModel):
    battery: float | None = None     # 0..1
    gps: Dict[str, Any] | None = None
    velocity: Dict[str, Any] | None = None
    extra: Dict[str, Any] | None = None

class PlanStep(BaseModel):
    action: Literal["connect","arm","takeoff","goto","loiter","land","rtl","orbit","stop","look_down","look_forward"]
    args: Dict[str, Any] = Field(default_factory=dict)
    guard: Optional[str] = None
    on_fail: Optional[str] = None

class MissionPlan(BaseModel):
    intent: str
    steps: List[PlanStep]
