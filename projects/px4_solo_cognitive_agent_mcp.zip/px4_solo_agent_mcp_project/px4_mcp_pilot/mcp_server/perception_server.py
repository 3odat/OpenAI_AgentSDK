
import asyncio
from typing import Any, Dict, Optional
import aiohttp
from mcp.server.fastmcp import FastMCP, Context

SCENE_URL   = "http://localhost:8088/scene"
SENSORS_URL = "http://localhost:8001/sensors"

mcp = FastMCP(name="PerceptionMCP")

_cache: Dict[str, Any] = {"scene": None, "sensors": None}

async def _fetch_json(url: str) -> Any:
    async with aiohttp.ClientSession() as s:
        async with s.get(url, timeout=3) as r:
            r.raise_for_status()
            return await r.json()

# Tools — structured results by returning dicts
@mcp.tool()
async def scene_now(ctx: Context) -> Dict[str, Any]:
    """Return the latest scene JSON (objects with xyz/gps/confidence)."""
    data = await _fetch_json(SCENE_URL)
    _cache["scene"] = data
    return data

@mcp.tool()
async def sensors_now(ctx: Context) -> Dict[str, Any]:
    """Return the latest sensors JSON (battery/gps/velocity)."""
    data = await _fetch_json(SENSORS_URL)
    _cache["sensors"] = data
    return data

# Resources — useful for 'read-only' context loads
@mcp.resource("perception://scene")
def scene_resource() -> str:
    return (str(_cache["scene"]) if _cache["scene"] is not None else "{}")

@mcp.resource("perception://sensors")
def sensors_resource() -> str:
    return (str(_cache["sensors"]) if _cache["sensors"] is not None else "{}")

async def poller():
    """Background poller to keep cache warm and demonstrate liveness."""
    while True:
        try:
            _cache["scene"] = await _fetch_json(SCENE_URL)
        except Exception:
            pass
        try:
            _cache["sensors"] = await _fetch_json(SENSORS_URL)
        except Exception:
            pass
        await asyncio.sleep(0.5)

def streamable_http_app():
    """Expose as an ASGI app for mounting under FastAPI/Starlette."""
    # Kick off poller when app starts
    app = mcp.streamable_http_app()
    # FastMCP provides lifespan support; we attach our poller via background task
    if hasattr(app, "state"):
        # Starlette app; add startup event
        @app.on_event("startup")
        async def _start():
            asyncio.create_task(poller())
    return app
