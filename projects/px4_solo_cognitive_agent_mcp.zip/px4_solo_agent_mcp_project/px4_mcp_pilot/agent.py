
from typing import Any
from agents import Agent, ModelSettings
from agents.mcp.server import MCPServerStreamableHttp
from .context import UAVContext
from .tools.control import connect, arm, takeoff, goto, loiter, land, rtl, orbit, look_down, look_forward, stop

BASE_RULES = (
    "- Prefer MCP tools for perception when available (scene/sensors).\n"
    "- Always ensure battery > params.min_batt before flight actions.\n"
    "- Never leave geofence radius; if violated, RTL immediately.\n"
    "- Prefer loiter at params.loiter_alt_m when awaiting new targets.\n"
    "- Confirm connection & arm state before takeoff.\n"
)

async def dynamic_instructions(ctx, _agent) -> str:
    s = ctx.context.caches.get("last_sensors", {})
    batt = s.get("battery", "unknown")
    return (
        "You are an autonomous PX4 pilot. Perceive, reason, and act.\n"
        f"Battery={batt}. Follow safety rules.\n" + BASE_RULES +
        "When the user gives a mission, first call MCP perception tools (scene_now, sensors_now). "
        "Then output a stepwise plan and execute steps using control tools. "
        "After each step, reassess sensors and scene; replan if needed."
    )

def create_agent(mcp_url: str = "http://localhost:5090/mcp") -> Agent[UAVContext]:
    mcp_server = MCPServerStreamableHttp(params={"url": mcp_url}, name="perception-mcp")
    return Agent[UAVContext](
        name="PX4 MCP Cognitive Pilot",
        instructions=dynamic_instructions,
        tools=[
            # Control tools (local) — perception is provided over MCP
            connect, arm, takeoff, goto, loiter, land, rtl, orbit, look_down, look_forward, stop,
        ],
        mcp_servers=[mcp_server],
        model="gpt-4.1",
        model_settings=ModelSettings(temperature=0.2, tool_choice="required"),
    )
