
import os
import asyncio
import json
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from agents import Runner
from px4_mcp_pilot.context import UAVContext
from px4_mcp_pilot.agent import create_agent
from px4_mcp_pilot.runtime.sessions import get_session
from px4_mcp_pilot.mcp_server.perception_server import streamable_http_app

# Load user's controller
from Agentic_Controller_v4 import AgenticController

app = FastAPI(title="PX4 MCP Cognitive Pilot")
static_dir = os.path.join(os.path.dirname(__file__), "static")
app.mount("/static", StaticFiles(directory=static_dir), name="static")
# Mount the MCP server under /mcp
app.mount("/mcp", streamable_http_app())

@app.get("/")
async def index():
    return FileResponse(os.path.join(static_dir, "index.html"))

# Singletons
controller = AgenticController()
agent = create_agent(mcp_url="http://localhost:5090/mcp")
session = get_session()
context = UAVContext(ctrl=controller)

# Event-driven trigger: when UI sends {event: "perception_delta"}, we run a quick tick
async def trigger_tick(text: str):
    result = Runner.run_streamed(agent, text, context=context, session=session, run_config={})
    async for event in result.stream_events():
        yield event

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except Exception:
                msg = {"text": raw}
            text = msg.get("text", "")

            # Run a single streamed turn and forward events
            async for event in trigger_tick(text):
                payload = None
                if getattr(event, "type", "") == "raw_response_event":
                    data = getattr(event, "data", None)
                    payload = {"kind": "thinking", "data": str(data)}
                elif getattr(event, "type", "") == "run_item_stream_event":
                    name = getattr(event, "name", "")
                    item = getattr(event, "item", None)
                    if name == "message_output_created":
                        payload = {"kind": "message", "data": getattr(item, "output_text", None) or str(item)}
                    elif name == "tool_called":
                        payload = {"kind": "acting", "data": getattr(item, "name", None) or "tool"}
                    elif name == "tool_output":
                        payload = {"kind": "observing", "data": str(getattr(item, "output", ""))}
                    elif name == "reasoning_item_created":
                        payload = {"kind": "reasoning", "data": str(getattr(item, "output_text", ""))}
                    else:
                        payload = {"kind": "event", "data": name}
                elif getattr(event, "type", "") == "agent_updated_stream_event":
                    payload = {"kind": "handoff", "data": getattr(event, "new_agent", None).__class__.__name__}
                else:
                    payload = {"kind": "event", "data": str(event)}
                await ws.send_text(json.dumps(payload))
    except WebSocketDisconnect:
        return
