
const streamEl = document.getElementById("stream");
const form = document.getElementById("chat");
const input = document.getElementById("input");

let ws;
function ensureWS() {
  if (ws && ws.readyState === WebSocket.OPEN) return;
  ws = new WebSocket(`ws://${location.host}/ws`);
  ws.onmessage = (ev) => {
    try {
      const data = JSON.parse(ev.data);
      addMsg(data.kind || "event", data.data || "");
    } catch (e) {
      addMsg("event", ev.data);
    }
    streamEl.scrollTop = streamEl.scrollHeight;
  };
  ws.onclose = () => addMsg("event", "• connection closed");
  ws.onopen  = () => addMsg("event", "• connected");
}

function addMsg(kind, text) {
  const div = document.createElement("div");
  div.className = `msg ${kind}`;
  const label = ({
    thinking: "thinking…",
    acting: "tool call",
    observing: "observation",
    message: "assistant",
    reasoning: "reasoning",
    handoff: "agent",
    event: "event"
  })[kind] || "event";
  div.innerHTML = `<small>${label}</small><div>${escapeHTML(text)}</div>`;
  streamEl.appendChild(div);
}

function escapeHTML(str) {
  return (str + "").replace(/[&<>'"]/g, s => ({
    "&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"
  })[s]);
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  ensureWS();
  const text = input.value.trim();
  if (!text) return;
  addMsg("event", `you → ${text}`);
  ws.send(JSON.stringify({ text }));
  input.value = "";
  input.focus();
});

ensureWS();
